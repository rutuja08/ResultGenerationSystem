/**
 * 
 */
package com.MCAResult.interfaces;

/**
 * @author nandan
 *
 */
public interface Course {
	int courseCode=0;
	String courseName=new String();
}
