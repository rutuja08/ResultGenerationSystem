/**
 * 
 */
package com.MCAResult.interfaces;

/**
 * @author nandan
 *
 */
public interface Subject {
	int subjectCode=0;
}
