/**
 * 
 */
package com.MCAResult.interfaces;

/**
 * @author nandan
 *
 */
public interface SecurityQuestionAnswer {
	String securityQuestion=new String();
	String securityAnswer=new String();
}
