/**
 * 
 */
package com.MCAResult.interfaces;

/**
 * @author nandan
 *
 */
public interface Assesment {
	int assesmentNo=0;	
}
