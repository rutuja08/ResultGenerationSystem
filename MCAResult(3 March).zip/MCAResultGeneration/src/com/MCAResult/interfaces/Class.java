/**
 * 
 */
package com.MCAResult.interfaces;

/**
 * @author nandan
 *
 */
public interface Class {
	int year=0;
}
