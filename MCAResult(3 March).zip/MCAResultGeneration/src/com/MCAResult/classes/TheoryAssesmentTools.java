/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Assesment;

/**
 * @author nandan
 *
 */
public class TheoryAssesmentTools implements Assesment{
	int theoryAssesmentNumber,maxMarks;

	/**
	 * 
	 */
	public TheoryAssesmentTools() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the theoryAssesmentNumber
	 */
	public int getTheoryAssesmentNumber() {
		return theoryAssesmentNumber;
	}

	/**
	 * @param theoryAssesmentNumber the theoryAssesmentNumber to set
	 */
	public void setTheoryAssesmentNumber(int theoryAssesmentNumber) {
		this.theoryAssesmentNumber = theoryAssesmentNumber;
	}

	/**
	 * @return the maxMarks
	 */
	public int getMaxMarks() {
		return maxMarks;
	}

	/**
	 * @param maxMarks the maxMarks to set
	 */
	public void setMaxMarks(int maxMarks) {
		this.maxMarks = maxMarks;
	}
}
