/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Subject;

/**
 * @author nandan
 *
 */
public class StudentSubject extends Student implements Subject{
	int studentSubjectNo;

	/**
	 * @return the studentSubjectNo
	 */
	public int getStudentSubjectNo() {
		return studentSubjectNo;
	}

	/**
	 * @param studentSubjectNo the studentSubjectNo to set
	 */
	public void setStudentSubjectNo(int studentSubjectNo) {
		this.studentSubjectNo = studentSubjectNo;
	}

	/**
	 * 
	 */
	public StudentSubject() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
