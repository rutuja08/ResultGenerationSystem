package com.MCAResult.classes;

import com.MCAResult.interfaces.Assesment;

public class InternalMarks extends StudentSubject implements Assesment{
	int marksId, noOfAttempts,obtainedMarks, studSubjectNumber;

	public int getMarksId() {
		return marksId;
	}

	public void setMarksId(int marksId) {
		this.marksId = marksId;
	}

	public int getNoOfAttempts() {
		return noOfAttempts;
	}

	public void setNoOfAttempts(int noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	public int getObtainedMarks() {
		return obtainedMarks;
	}

	public void setObtainedMarks(int obtainedMarks) {
		this.obtainedMarks = obtainedMarks;
	}

	public int getStudSubjectNumber() {
		return studSubjectNumber;
	}

	public void setStudSubjectNumber(int studSubjectNumber) {
		this.studSubjectNumber = studSubjectNumber;
	}

	public InternalMarks() {
		super();
		// TODO Auto-generated constructor stub
	}

}
