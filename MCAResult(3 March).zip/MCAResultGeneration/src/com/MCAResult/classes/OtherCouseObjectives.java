/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Subject;

/**
 * @author nandan
 *
 */
public class OtherCouseObjectives implements Subject{
	int otherCouseId,otherCouseNo;
	String otherCourseName;
}

