/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Assesment;

/**
 * @author nandan
 *
 */
public class OtherAssesmentTools implements Assesment {
	int otherAssesmentNumber, maxMarks;

	/**
	 * 
	 */
	public OtherAssesmentTools() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the otherAssesmentNumber
	 */
	public int getotherAssesmentNumber() {
		return otherAssesmentNumber;
	}

	/**
	 * @param otherAssesmentNumber the otherAssesmentNumber to set
	 */
	public void setotherAssesmentNumber(int otherAssesmentNumber) {
		this.otherAssesmentNumber = otherAssesmentNumber;
	}

	/**
	 * @return the maxMarks
	 */
	public int getMaxMarks() {
		return maxMarks;
	}

	/**
	 * @param maxMarks the maxMarks to set
	 */
	public void setMaxMarks(int maxMarks) {
		this.maxMarks = maxMarks;
	}
}
