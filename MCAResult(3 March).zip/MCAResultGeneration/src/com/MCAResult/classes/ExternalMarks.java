/**
 * 
 */
package com.MCAResult.classes;

/**
 * @author nandan
 *
 */
public class ExternalMarks extends StudentSubject{
	int externalMarksId,noOfAttempts,obtainedMarks,obtainedCreditPoints;

	/**
	 * @return the externalMarksId
	 */
	public int getExternalMarksId() {
		return externalMarksId;
	}

	/**
	 * @param externalMarksId the externalMarksId to set
	 */
	public void setExternalMarksId(int externalMarksId) {
		this.externalMarksId = externalMarksId;
	}

	/**
	 * @return the noOfAttempts
	 */
	public int getNoOfAttempts() {
		return noOfAttempts;
	}

	/**
	 * @param noOfAttempts the noOfAttempts to set
	 */
	public void setNoOfAttempts(int noOfAttempts) {
		this.noOfAttempts = noOfAttempts;
	}

	/**
	 * @return the obtainedMarks
	 */
	public int getObtainedMarks() {
		return obtainedMarks;
	}

	/**
	 * @param obtainedMarks the obtainedMarks to set
	 */
	public void setObtainedMarks(int obtainedMarks) {
		this.obtainedMarks = obtainedMarks;
	}

	/**
	 * @return the obtainedCreditPoints
	 */
	public int getObtainedCreditPoints() {
		return obtainedCreditPoints;
	}

	/**
	 * @param obtainedCreditPoints the obtainedCreditPoints to set
	 */
	public void setObtainedCreditPoints(int obtainedCreditPoints) {
		this.obtainedCreditPoints = obtainedCreditPoints;
	}

	/**
	 * 
	 */
	public ExternalMarks() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
