/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Subject;

/**
 * @author nandan
 *
 */
public class FacultySubject extends AdminFacultyUser implements Subject{
	int facultySubjectId,facultyId,academicYear;
}
