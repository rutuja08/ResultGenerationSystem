/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Assesment;

/**
 * @author nandan
 *
 */
public class PracticleAssesmentTools implements Assesment {
	int practicleAssesmentNumber, maxMarks;

	/**
	 * 
	 */
	public PracticleAssesmentTools() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the practicleAssesmentNumber
	 */
	public int getpracticleAssesmentNumber() {
		return practicleAssesmentNumber;
	}

	/**
	 * @param PracticleAssesmentNumber the practicleAssesmentNumber to set
	 */
	public void setpracticleAssesmentNumber(int practicleAssesmentNumber) {
		this.practicleAssesmentNumber = practicleAssesmentNumber;
	}

	/**
	 * @return the maxMarks
	 */
	public int getMaxMarks() {
		return maxMarks;
	}

	/**
	 * @param maxMarks the maxMarks to set
	 */
	public void setMaxMarks(int maxMarks) {
		this.maxMarks = maxMarks;
	}
}
