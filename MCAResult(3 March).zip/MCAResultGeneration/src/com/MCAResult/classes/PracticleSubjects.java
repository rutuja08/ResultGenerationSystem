/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Course;
import com.MCAResult.interfaces.Subject;

/**
 * @author nandan
 *
 */
public class PracticleSubjects implements Course,Subject {
	int practicleSubjectCode,maxCreditPoints;
	String practicleSubjectName;
	/**
	 * @return the practicleSubjectCode
	 */
	public int getpracticleSubjectCode() {
		return practicleSubjectCode;
	}
	/**
	 * @param practicleSubjectCode the practicleSubjectCode to set
	 */
	public void setpracticleSubjectCode(int practicleSubjectCode) {
		this.practicleSubjectCode = practicleSubjectCode;
	}
	/**
	 * @return the maxCreditPoints
	 */
	public int getMaxCreditPoints() {
		return maxCreditPoints;
	}
	/**
	 * @param maxCreditPoints the maxCreditPoints to set
	 */
	public void setMaxCreditPoints(int maxCreditPoints) {
		this.maxCreditPoints = maxCreditPoints;
	}
	/**
	 * @return the practicleSubjectName
	 */
	public String getpracticleSubjectName() {
		return practicleSubjectName;
	}
	/**
	 * @param practicleSubjectName the practicleSubjectName to set
	 */
	public void setpracticleSubjectName(String practicleSubjectName) {
		this.practicleSubjectName = practicleSubjectName;
	}
	/**
	 * 
	 */
	public PracticleSubjects() {
		super();
		// TODO Auto-generated constructor stub
	}
}
