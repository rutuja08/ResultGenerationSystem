/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Course;
import com.MCAResult.interfaces.Subject;

/**
 * @author nandan
 *
 */
public class TheorySubjects implements Course,Subject {
	int theorySubjectCode,maxCreditPoints;
	String theorySubjectName;
	/**
	 * @return the theorySubjectCode
	 */
	public int getTheorySubjectCode() {
		return theorySubjectCode;
	}
	/**
	 * @param theorySubjectCode the theorySubjectCode to set
	 */
	public void setTheorySubjectCode(int theorySubjectCode) {
		this.theorySubjectCode = theorySubjectCode;
	}
	/**
	 * @return the maxCreditPoints
	 */
	public int getMaxCreditPoints() {
		return maxCreditPoints;
	}
	/**
	 * @param maxCreditPoints the maxCreditPoints to set
	 */
	public void setMaxCreditPoints(int maxCreditPoints) {
		this.maxCreditPoints = maxCreditPoints;
	}
	/**
	 * @return the theorySubjectName
	 */
	public String getTheorySubjectName() {
		return theorySubjectName;
	}
	/**
	 * @param theorySubjectName the theorySubjectName to set
	 */
	public void setTheorySubjectName(String theorySubjectName) {
		this.theorySubjectName = theorySubjectName;
	}
	/**
	 * 
	 */
	public TheorySubjects() {
		super();
		// TODO Auto-generated constructor stub
	}
}
