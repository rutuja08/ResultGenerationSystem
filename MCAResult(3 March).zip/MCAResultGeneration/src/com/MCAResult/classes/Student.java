/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Course;
import com.MCAResult.interfaces.SecurityQuestionAnswer;

/**
 * @author nandan
 *
 */
public class Student implements Course,SecurityQuestionAnswer{
	String prn,studentName,mailId,password,contact,joiningYear,sex,address,phoneNo;
	int courseCode;
	/**
	 * @return the prn
	 */
	public String getPrn() {
		return prn;
	}
	/**
	 * @param prn the prn to set
	 */
	public void setPrn(String prn) {
		this.prn = prn;
	}
	/**
	 * @return the studentName
	 */
	public String getStudentName() {
		return studentName;
	}
	/**
	 * @param studentName the studentName to set
	 */
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	/**
	 * @return the mailId
	 */
	public String getMailId() {
		return mailId;
	}
	/**
	 * @param mailId the mailId to set
	 */
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the contact
	 */
	public String getContact() {
		return contact;
	}
	/**
	 * @param contact the contact to set
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}
	/**
	 * @return the joiningYear
	 */
	public String getJoiningYear() {
		return joiningYear;
	}
	/**
	 * @param joiningYear the joiningYear to set
	 */
	public void setJoiningYear(String joiningYear) {
		this.joiningYear = joiningYear;
	}
	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}
	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	/**
	 * @return the courseCode
	 */
	public int getCourseCode() {
		return courseCode;
	}
	/**
	 * @param courseCode the courseCode to set
	 */
	public void setCourseCode(int courseCode) {
		this.courseCode = courseCode;
	}
	/**
	 * 
	 */
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
