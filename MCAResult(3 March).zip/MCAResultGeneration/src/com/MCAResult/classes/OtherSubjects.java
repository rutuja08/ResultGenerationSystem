/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Course;
import com.MCAResult.interfaces.Subject;

/**
 * @author nandan
 *
 */
public class OtherSubjects implements Course,Subject {
	int otherSubjectCode,maxCreditPoints;
	String otherSubjectName;
	/**
	 * @return the otherSubjectCode
	 */
	public int getotherSubjectCode() {
		return otherSubjectCode;
	}
	/**
	 * @param otherSubjectCode the otherSubjectCode to set
	 */
	public void setotherSubjectCode(int otherSubjectCode) {
		this.otherSubjectCode = otherSubjectCode;
	}
	/**
	 * @return the maxCreditPoints
	 */
	public int getMaxCreditPoints() {
		return maxCreditPoints;
	}
	/**
	 * @param maxCreditPoints the maxCreditPoints to set
	 */
	public void setMaxCreditPoints(int maxCreditPoints) {
		this.maxCreditPoints = maxCreditPoints;
	}
	/**
	 * @return the otherSubjectName
	 */
	public String getotherSubjectName() {
		return otherSubjectName;
	}
	/**
	 * @param otherSubjectName the otherSubjectName to set
	 */
	public void setotherSubjectName(String otherSubjectName) {
		this.otherSubjectName = otherSubjectName;
	}
	/**
	 * 
	 */
	public OtherSubjects() {
		super();
		// TODO Auto-generated constructor stub
	}
}
