/**
 * 
 */
package com.MCAResult.classes;

import com.MCAResult.interfaces.Subject;

/**
 * @author nandan
 *
 */
public class TheoryCouseObjectives implements Subject{
	int theoryCouseId,theoryCouseNo;
	String theoryCourseName;
}
